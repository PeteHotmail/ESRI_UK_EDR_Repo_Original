/**
 * String resources for the application
 */
const strings = {
    ROUTE_NOT_FOUND: "Not Found.",
    GENERAL_ERROR: "Internal Error"
};

export default strings;